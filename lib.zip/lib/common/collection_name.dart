class CollectionName{
  String admin ="admin";
  String banner ="banner";
  String static ="static";
}