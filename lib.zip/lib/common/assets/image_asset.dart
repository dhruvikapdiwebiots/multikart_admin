class ImageAssets{
  final String logo = 'assets/images/logo.png';
  final String logo1 = 'assets/images/logo1.png';
  final String logo2 = 'assets/images/logo2.png';
  final String noData = 'assets/images/noData.png';
}