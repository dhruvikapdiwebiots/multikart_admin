class GifAssets{
  final String check ="assets/gif/check.gif";
  final String wave ="assets/gif/wave.gif";
}