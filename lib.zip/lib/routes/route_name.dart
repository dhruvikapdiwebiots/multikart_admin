class RouteName {
  final String login = '/login';
  final String index = '/index';
  final String dashboard = '/dashboard';
}
